### Hexlet tests and linter status:
[![Actions Status](https://github.com/MaksimGoryachev/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/MaksimGoryachev/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/3ba217970a150c790db8/maintainability)](https://codeclimate.com/github/MaksimGoryachev/python-project-49/maintainability)
https://asciinema.org/a/iWvkh0oOZu6oZKeSWlJGp8LTH
https://asciinema.org/a/NRZtse3WL4tiBKSkMNifk5NqD
